abstract class AtomicFormula {

        abstract void printParseTree(String indent);
    
    
}
