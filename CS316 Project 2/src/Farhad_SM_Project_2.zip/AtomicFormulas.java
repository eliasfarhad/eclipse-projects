public abstract class AtomicFormulas {

    AtomicFormula atomicformula;
    abstract void printParseTree(String indent);
    
}
