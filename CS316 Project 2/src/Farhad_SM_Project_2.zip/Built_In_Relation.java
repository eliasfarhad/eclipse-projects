public abstract class Built_In_Relation extends AtomicFormula {

    abstract void printParseTree(String indent);

}
