public abstract class Clauses {

         abstract void printParseTree(String indent);
    
    
    
}
