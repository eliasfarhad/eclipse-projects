public abstract class Comp_Op_1 {

    abstract void printParseTree(String indent);
    
    
}
