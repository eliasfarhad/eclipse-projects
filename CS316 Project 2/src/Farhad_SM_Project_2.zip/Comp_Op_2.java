public abstract class Comp_Op_2 {

    abstract void printParseTree(String indent);
    
    
}
