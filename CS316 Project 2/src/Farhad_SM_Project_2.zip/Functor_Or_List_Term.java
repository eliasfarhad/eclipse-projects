public abstract class Functor_Or_List_Term extends Term {

    abstract void printParseTree(String indent);
    
}
