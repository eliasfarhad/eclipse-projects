public class Node {

   public Integer coef;
   public Integer exp;
   public Node next;
   
   public Node(Integer c, Integer e, Node n) {                 
      coef = c;
      exp = e;
      next = n;
   }
   
}

